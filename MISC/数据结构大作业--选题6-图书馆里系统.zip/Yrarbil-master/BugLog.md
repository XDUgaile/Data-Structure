# Bug Log
This file is the log of the bugs of this project.
