﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wanju2.data
{
    public class librarydata
    {
        public string libintroduction;
        public string hotbooks;
        public string newbooks;
    }
}
