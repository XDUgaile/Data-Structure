﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wanju2.data
{
    public class logindata
    {
        public string username;
        public string passwords;
    }
}
