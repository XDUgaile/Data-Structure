﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wanju2.data
{
     public class serch
    {
        public string booknumber;
        public string requirement1;
        public string requirement2;
        public string requirement3;
        public string serchresult;
        public string details;
    }
}
